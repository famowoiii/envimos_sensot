<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Sensor;

class SensorController extends Controller
{

    public function index()
    {
        return view('dashboard');
    }

    public function create($id)
    {

        Sensor::create([
            'nama_alat' => $id,
            'suhu' => $id,
            'hum' => $id,
            'co2' => $id,
        ]);

        return view('dashboard');
    }
}
